package com.example.goodjoob.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.goodjoob.R;

public class Alterar_Servico extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alterar_seu_servico);

    }
}