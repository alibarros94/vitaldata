package com.example.goodjoob.db;

import android.content.Intent;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.goodjoob.ui.ProjetoBradescoMainActivity;
import com.example.goodjoob.util.Constantes;
import com.example.goodjoob.webservice.HttpRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class conexao {

    private StringRequest request;
    HttpRequest http = new HttpRequest();




}

