package com.example.goodjoob.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

import com.example.goodjoob.R;
import com.example.goodjoob.db.SolicitacaosAdapter;
import com.example.goodjoob.model.Solicitacoes;

public class Adicionar_Servico extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adicionar_um_servico);

    }
}