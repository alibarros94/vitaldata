package com.example.goodjoob.util;

public class Constantes {

    public static final String HOST = "http://conect.vitaldata.com.br/tentativa5/";
    public static final String CADASTRAR = HOST+"cadaster.php";
    public static final String LOGAR = HOST+"user_control.php";
    public static final String ORCAMENTO = HOST+"solicitando.php";
    public static final String SOLICITACOES = HOST+"solicitacoes.php";
    public static final String TRABALHOS = HOST+"trabalhos.php";
    public static final String SERVICOS = HOST+"lista_servicos_do_tecnico.php";
    public static final String CANCELAR_SERV = HOST+"cancelar_servico.php";

    public static final String TIPO_CLIENTE = "Cliente";
}
