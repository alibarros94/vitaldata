package com.example.goodjoob.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.goodjoob.R;
import com.example.goodjoob.db.SolicitacaosAdapter;
import com.example.goodjoob.model.Handle;
import com.example.goodjoob.model.Perfil;
import com.example.goodjoob.model.Solicitacoes;
import com.example.goodjoob.util.Constantes;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Tela_Solicitacao_Cliente extends AppCompatActivity {
    private Button voltar;
    Bundle bundleExtra;
    int posicaoExtra;
    private TextView Data;
    private TextView Nome;
    private TextView Status;
    private Button avaliarServ;
    Solicitacoes s;
    private Button cancelar;
    private HashMap<String, String> hashMap;
    private StringRequest request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_de_solicitacao_cliente);


        bundleExtra = getIntent().getExtras();
        posicaoExtra = Integer.parseInt(bundleExtra.get("posicao").toString());
        s = SolicitacaosAdapter.solicitacaoList.get(posicaoExtra);

        Nome = (TextView) findViewById(R.id.textNomeTecNoServ);
        Data = (TextView) findViewById(R.id.textTextData);
        avaliarServ = (Button) findViewById(R.id.buttonAvaliarServ);

        Nome.setText(s.getNomeTecnicoSoli());
        Data.setText(s.getData_orcamento());

        avaliarServ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Tela_Solicitacao_Cliente.this, Tela_Avaliando_Tecnico.class);
                intent.putExtra("posicao",posicaoExtra);
                startActivity(intent);

            }
        });
        cancelar = (Button) findViewById(R.id.buttonCanSoli);

        new AlertDialog.Builder(this)
                .setTitle("Deletando curso")
                .setMessage("Tem certeza que deseja deletar esse curso?")
                .setPositiveButton("sim",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                .show();

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StringRequest stringRequest = new StringRequest(Request.Method.POST, Constantes.CANCELAR_SERV, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if (jsonObject.names().get(0).equals("success")) {
                                Toast.makeText(getApplicationContext(), "ATENÇÃO: Cancelado com sucesso ", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), ListarSolicitacoes.class));
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "ATENÇÃO: " + jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),  e.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        hashMap = new HashMap<String, String>();
                        hashMap.put("solicitante", Perfil.getId_usuario());
                        hashMap.put("id_servico", s.getId_orcamento());
                        return hashMap;
                    }
                };
                //requestQueue.add(request);
                Handle.getInstance(getApplicationContext()).addToRequestQue(stringRequest);

            }
        });

    }
}